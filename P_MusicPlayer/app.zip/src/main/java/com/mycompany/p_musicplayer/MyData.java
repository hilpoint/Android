package com.mycompany.p_musicplayer;

/**
 * Created by c on 2015-12-13.
 */
public class MyData {
    String file_name;
    String file_size;
    int imgIcon;

    public MyData(String file_name, String file_size, int imgIcon) {
        this.file_name = file_name;
        this.file_size = file_size;
        this.imgIcon = imgIcon;
    }
}